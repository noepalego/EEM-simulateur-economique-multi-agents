import numpy as np
from economy.simulation import EconomySimulation
from economy.models import SimulationConfig

def run_diag(seed=7, months=120):
    config = SimulationConfig(seed=seed)
    sim = EconomySimulation(config)
    history = []
    
    for m in range(months):
        rec = sim.step()
        # trésoreries
        people_cash = sum(p.cash for p in sim.people)
        firm_cash = sum(c.cash for c in sim.companies if c.active and c.sector != 'bank')
        bank_cash = sum(c.cash for c in sim.companies if c.active and c.sector == 'bank')
        gov_cash = sim.government_balance
        market_cash = sim.resources.market_cash
        
        # emplois
        emp_firm = sum(1 for p in sim.people if p.employer_id is not None)
        emp_service = sim.resources.supplier_employment
        
        history.append({
            'month': rec.month,
            'gdp': rec.nominal_gdp,
            'housing_build': rec.housing_construction,
            'recurrent_gdp': rec.nominal_gdp - rec.housing_construction,
            'wage': rec.average_wage,
            'real_wage': rec.real_average_wage,
            'unemployment': rec.unemployment,
            'emp_firm': emp_firm,
            'emp_service': emp_service,
            'total_profit': rec.total_profit,
            'active_companies': len([c for c in sim.companies if c.active]),
            'people_cash': people_cash,
            'firm_cash': firm_cash,
            'bank_cash': bank_cash,
            'gov_cash': gov_cash,
            'market_cash': market_cash,
            'cpi': rec.consumer_price_index,
            'inflation': rec.inflation_rate,
            'propensity': np.mean([p.consumption_propensity for p in sim.people])
        })
    return history

if __name__ == '__main__':
    for seed in [7, 42, 123, 999, 2024]:
        h = run_diag(seed)
        print(f"=== SEED {seed} ===")
        print(f"Month 1-4 GDP avg: {np.mean([x['gdp'] for x in h[:4]]):.0f} (housing build: {np.mean([x['housing_build'] for x in h[:4]]):.0f})")
        print(f"Month 120 GDP: {h[-1]['gdp']:.0f} (recurrent: {h[-1]['recurrent_gdp']:.0f})")
        print(f"GDP 12m avg (m108-120): {np.mean([x['gdp'] for x in h[-12:]]):.0f} (recurrent: {np.mean([x['recurrent_gdp'] for x in h[-12:]]):.0f})")
        gdp_windows = [np.mean([x['gdp'] for x in h[i:i+12]]) for i in range(0, 109, 12)]
        print(f"GDP 12m windows (m1,13,25,...): {[f'{g:.0f}' for g in gdp_windows]}")
        print(f"Unemployment m108-120 avg: {np.mean([x['unemployment'] for x in h[-12:]])*100:.1f}%, min: {min(x['unemployment'] for x in h)*100:.1f}%, max: {max(x['unemployment'] for x in h)*100:.1f}%")
        print(f"Services emp m15-30 avg: {np.mean([x['emp_service'] for x in h[14:30]]):.1f}, m108-120 avg: {np.mean([x['emp_service'] for x in h[-12:]]):.1f}")
        wage_windows = [np.mean([x['wage'] for x in h[i:i+12]]) for i in range(0, 109, 12)]
        print(f"Wage 12m windows: {[f'{w:.0f}' for w in wage_windows]}")
        print(f"Total Profit 12m windows: {[f'{np.mean([x[chr(39)+chr(39)] if False else x['total_profit'] for x in h[i:i+12]]):.0f}' for i in range(0, 109, 12)]}")
        print(f"Cash m120 -> People: {h[-1]['people_cash']:.0f}, Firms: {h[-1]['firm_cash']:.0f}, Banks: {h[-1]['bank_cash']:.0f}, Gov: {h[-1]['gov_cash']:.0f}, Market: {h[-1]['market_cash']:.0f}")
        cpi_first, cpi_last = h[0]['cpi'], h[-1]['cpi']
        ann_inf = ((cpi_last/cpi_first)**(12/(len(h)-1)) - 1)*100
        print(f"CPI m1: {cpi_first:.1f} -> m120: {cpi_last:.1f} (annualized: {ann_inf:.1f}%)")
        print(f"Avg Propensity m120: {h[-1]['propensity']:.2f}")
        print()

