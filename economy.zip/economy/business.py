from __future__ import annotations

import random

from economy.models import Company, Person, Resources, SimulationConfig


def elect_executives(
    companies: list[Company],
    people: list[Person],
    config: SimulationConfig,
    rng: random.Random,
) -> None:
    people_by_id = {person.id: person for person in people}
    for company in companies:
        if not company.active:
            continue
        current = people_by_id.get(company.executive_id or "")
        current_is_employee = current is not None and current.employer_id == company.id
        # CEO indéterminé : ne jamais forcer un remplacement si le CEO actuel est bon
        if current_is_employee and getattr(config, 'ceo_term_indeterminate', True):
            company.ceo_tenure += 1
            current.leadership_experience += 1
            company.ceo_experience += 1
            # rémunération en actions pour les bons CEO
            if company.profit > 0 and company.cash > company.target_employees * company.wage_offer * 1.0:
                equity_bonus = company.profit * getattr(config, 'ceo_equity_bonus_rate', 0.02)
                equity_bonus = min(equity_bonus, company.cash * 0.05)
                if equity_bonus > 0:
                    # attribuer des actions au CEO via dilution sans mouvement de trésorerie
                    shares_to_grant = equity_bonus / max(company.stock_price, 1.0)
                    current.shares[company.id] = current.shares.get(company.id, 0.0) + shares_to_grant
                    company.shares_outstanding += shares_to_grant
                    # Pas de déduction de cash, la rémunération est par dilution
            continue
        # Ancien système pour les termes limités
        term_expired = company.ceo_tenure >= max(1, config.ceo_term_months)
        if current_is_employee and not term_expired:
            company.ceo_tenure += 1
            current.leadership_experience += 1
            company.ceo_experience += 1
            continue

        candidates = [people_by_id[person_id] for person_id in company.employees if person_id in people_by_id]
        if not candidates:
            company.executive_id = None
            company.ceo_tenure = 0
            continue
        candidates.sort(
            key=lambda person: (
                person.skill * (1.0 + min(person.employer_tenure, 120) / 240.0)
                + person.leadership_experience / 600.0
                + rng.uniform(-config.random_promotion_strength, config.random_promotion_strength),
                person.id,
            ),
            reverse=True,
        )
        company.executive_id = candidates[0].id
        company.ceo_tenure = 0
        company.ceo_experience += 1


def apply_competitive_pricing(
    companies: list[Company],
    food_index: float,
    goods_index: float,
    competition_strength: float = 0.12,
    inventory_discount_strength: float = 0.08,
) -> None:
    """Higher pricing aggression trades per-unit margin for a larger share of demand."""
    for company in companies:
        if not company.active:
            continue
        market_index = food_index if company.sector == "food" else goods_index
        if company.sector not in ("food", "goods"):
            continue
        markup = 1.0 + competition_strength * (0.5 - company.pricing_aggression) * 2.0
        scarcity_adjustment = max(
            0.92,
            min(1.08, 1.0 + company.previous_profit / max(company.cash + 10000.0, 1.0) * 0.08),
        )
        inventory = (
            company.inventory if company.sector == "food" else company.goods_inventory
        )
        monthly_capacity = max(1.0, len(company.employees) * 24.0)
        surplus_stock = max(0.0, inventory / monthly_capacity - 1.0)
        inventory_adjustment = max(
            0.75,
            1.0 - max(0.0, inventory_discount_strength) * surplus_stock,
        )
        company.price = max(
            1.0,
            market_index * markup * scarcity_adjustment * inventory_adjustment,
        )


def adjust_profit_sharing_wages(
    companies: list[Company],
    people: list[Person],
    starting_wage: float,
    bonus_rate: float,
    productivity_share: float = 0.35,
    loss_adjustment_strength: float = 0.70,
    unemployment_rate: float = 0.0,
    unemployment_sensitivity: float = 0.0,
) -> None:
    people_by_id = {person.id: person for person in people}
    for company in companies:
        if not company.active:
            continue
        profitability = max(-0.4, min(0.20, company.profit / max(company.revenue, 1.0)))
        measured_productivity = company.productivity_trait * (
            1.0 + min(company.tech_level, 10.0) * 0.04
        )
        # renforcer le lien salaires-productivité et marché du travail
        productivity_bonus = (measured_productivity - 1.0) * 0.18 * productivity_share
        profitability_bonus = profitability * 0.18
        # pression du marché du travail plus réactive
        labor_market_pressure = max(
            -0.6,
            min(0.6, (0.06 - unemployment_rate) * (unemployment_sensitivity * 2.5)),
        )
        adjustment = 1.0 + profitability_bonus + productivity_bonus + labor_market_pressure
        if profitability < 0.0:
            adjustment *= max(
                0.80, 1.0 + profitability * loss_adjustment_strength * 0.7
            )
        # lissage pour éviter les chutes brutales de salaire
        company.wage_offer = max(
            starting_wage * 0.65,
            min(starting_wage * 1.85, company.wage_offer * 0.80 + company.wage_offer * adjustment * 0.20),
        )
        if company.profit <= 0.0 or not company.employees:
            continue
        bonus_pool = min(
            company.cash,
            company.profit * bonus_rate * company.reinvestment_preference,
        )
        if bonus_pool <= 0.0:
            continue
        bonus_per_employee = bonus_pool / len(company.employees)
        for employee_id in company.employees:
            person = people_by_id.get(employee_id)
            if person is not None:
                person.cash += bonus_per_employee
                person.income_this_turn += bonus_per_employee
                person.lifetime_earnings += bonus_per_employee
        company.cash -= bonus_pool
        company.expenses += bonus_pool


def invest_in_innovation(
    companies: list[Company],
    rng: random.Random,
    resources: Resources | None = None,
) -> float:
    """Retained profits fund research; innovation improves productivity stochastically."""
    total_spent = 0.0
    for company in companies:
        if not company.active or company.profit <= 0.0 or company.reinvestment_preference <= 0.0:
            continue
        research_budget = min(
            company.cash * 0.08,
            company.profit * company.reinvestment_preference * 0.12,
        )
        if research_budget < 1.0:
            continue
        company.cash -= research_budget
        if resources is not None:
            resources.market_cash += research_budget
        company.expenses += research_budget
        total_spent += research_budget
        improvement = research_budget / max(company.cash + research_budget, 1.0)
        success_factor = max(0.0, rng.gauss(company.innovation, 0.12))
        company.productivity_trait = min(
            1.8, company.productivity_trait + min(0.015, improvement * success_factor)
        )
    return total_spent


def invest_in_production_capacity(
    companies: list[Company],
    unmet_demand: dict[str, float],
    config: SimulationConfig,
    resources: Resources,
) -> float:
    """Reinvest profitable cash in durable monthly output capacity."""
    total_investment = 0.0
    for sector in ("food", "goods"):
        if unmet_demand.get(sector, 0.0) <= 0.0:
            continue
        producers = [
            company
            for company in companies
            if company.active and company.sector == sector
        ]
        if not producers:
            continue
        for company in producers:
            if company.profit <= 0.0:
                continue
            wage_reserve = company.wage_offer * max(1, len(company.employees)) * 1.5
            available_cash = max(0.0, company.cash - wage_reserve)
            profit_margin = company.profit / max(company.revenue, 1.0)
            # relancer l'investissement si la marge est faible mais la demande existe
            target_margin = getattr(config, 'profit_margin_target', 0.05)
            if profit_margin < target_margin and unmet_demand.get(sector, 0.0) > 0:
                investment = min(
                    company.profit * config.capacity_expansion_reinvestment_rate * 2.0,
                    available_cash * 0.15,
                )
            else:
                investment = min(
                    company.profit * config.capacity_expansion_reinvestment_rate,
                    available_cash * 0.05,
                )
            if investment < config.productive_capacity_unit_cost * 0.05:
                continue
            company.cash -= investment
            company.capital_expenditure += investment
            company.production_capacity += (
                investment / config.productive_capacity_unit_cost
            )
            company.productive_capital_value += investment
            resources.market_cash += investment
            total_investment += investment
    return total_investment
