from __future__ import annotations

import random

from economy.business import (
    adjust_profit_sharing_wages,
    apply_competitive_pricing,
    elect_executives,
    invest_in_innovation,
    invest_in_production_capacity,
)
from economy.consolidation import consolidate_market
from economy.finance import (
    create_household_startups,
    request_operating_credit,
    resolve_distressed_companies,
    service_company_debt,
)
from economy.goods import (
    charge_inventory_holding_cost,
    collect_recyclable_materials,
    produce_consumer_goods,
    produce_food,
    sell_consumer_goods,
    sell_food,
    trade_technology,
    update_food_price,
)
from economy.government import collect_income_taxes_and_pay_benefits, tax_company_profits
from economy.labor import (
    allocate_and_pay_labor,
    effective_worker_count,
    hire_service_workers,
    workforce_targets,
)
from economy.models import Company, MarketRecord, Person, Resources, SimulationConfig
from economy.real_estate import (
    allocate_housing_and_collect_rent,
    build_housing,
    buy_homes,
    complete_construction,
    maintain_housing,
    service_mortgages,
)
from economy.stock_market import distribute_dividends, update_prices_and_trade
from economy.wealth import enrich_wealth_record, wealth_leaderboards


SECTORS = (
    ("food", "Alimentation"),
    ("goods", "Biens courants"),
    ("technology", "Technologie"),
    ("real_estate", "Immobilier"),
    ("materials", "Matières premières"),
    ("bank", "Banque"),
    ("services", "Services aux entreprises"),
)


class EconomySimulation:
    def __init__(self, config: SimulationConfig | None = None) -> None:
        self.config = config or SimulationConfig()
        self.random = random.Random(self.config.seed)
        self.month = 0
        self.food_price = self.config.starting_food_price
        self.goods_price = self.config.starting_goods_price
        self.rent = self.config.starting_rent
        self.price_index = 100.0
        self.wage_reference = self.config.starting_wage
        self.policy_rate = self.config.loan_interest_rate
        self.people = [
            Person(
                f"p{i:04d}",
                f"Ménage {i + 1}",
                self.config.initial_person_cash,
                skill=self.random.uniform(0.65, 1.35),
                risk_tolerance=self.random.random(),
                consumption_propensity=self.random.uniform(
                    1.0 - self.config.household_propensity_variance,
                    1.0 + self.config.household_propensity_variance,
                ),
                quality_preference=self.random.uniform(0.65, 1.35),
            )
            for i in range(self.config.population_size)
        ]
        self.initial_population_size = len(self.people)
        self.population_growth_progress = 0.0
        self.population_job_progress = 0.0
        self.new_households_this_turn = 0
        self.companies = self._create_companies()
        initial_housing = min(
            self.config.land_units,
            max(1, int(len(self.people) * 0.9)),
        )
        property_firms = [company for company in self.companies if company.sector == "real_estate"]
        for index in range(initial_housing):
            property_firms[index % len(property_firms)].property_inventory += 1
        for company in self.companies:
            initial_assets = (
                company.cash + company.property_inventory * self.config.housing_price
            )
            company.stock_price = max(
                1.0,
                min(
                    5000.0,
                    initial_assets / max(company.shares_outstanding, 1.0),
                ),
            )
            company.previous_stock_price = company.stock_price
        self.resources = Resources(
            raw_materials=max(0.0, self.config.raw_materials),
            land_units=max(0, self.config.land_units - initial_housing),
            knowledge=max(100.0, self.config.raw_materials * 0.25),
            raw_material_price=self.config.raw_material_unit_price,
        )
        self.history: list[MarketRecord] = []
        self.last_event = "Aucun événement"
        self.government_balance = 0.0
        self.total_tax_revenue = 0.0
        self.total_benefits_paid = 0.0
        self.bank_reserves = max(0.0, self.config.bank_initial_reserves)
        self.total_defaults = 0

    def _create_companies(self) -> list[Company]:
        companies: list[Company] = []
        targets = workforce_targets(self.config)
        for sector, label in SECTORS:
            if sector == "services":
                continue
            for index in range(self.config.companies_per_sector):
                company_id = f"{sector}_{index + 1}"
                initial_cash = (
                    self.config.bank_initial_reserves
                    / self.config.companies_per_sector
                    if sector == "bank"
                    else self.config.initial_company_cash
                )
                companies.append(
                    Company(
                        id=company_id,
                        name=f"{label} {index + 1}",
                        sector=sector,
                        cash=initial_cash,
                        wage_offer=self.config.starting_wage * self.random.uniform(0.92, 1.08),
                        target_employees=targets[sector],
                        price=(
                            self.config.starting_food_price
                            if sector == "food"
                            else self.config.raw_material_unit_price
                            if sector == "materials"
                            else self.config.starting_goods_price
                        ),
                        stock_price=max(1.0, self.config.initial_company_cash / 1000.0),
                        previous_stock_price=max(1.0, self.config.initial_company_cash / 1000.0),
                        productivity_trait=self.random.uniform(
                            1.0 - self.config.trait_variance,
                            1.0 + self.config.trait_variance,
                        ),
                        quality_trait=self.random.uniform(
                            1.0 - self.config.quality_trait_variance,
                            1.0 + self.config.quality_trait_variance,
                        ),
                        risk_tolerance=self.random.random(),
                        pricing_aggression=self.random.random(),
                        reinvestment_preference=max(
                            0.05,
                            min(
                                1.0,
                                self.config.investment_retention_rate
                                + self.random.uniform(-0.3, 0.3),
                            ),
                        ),
                        innovation=self.random.uniform(0.4, 1.0),
                        bank_equity=initial_cash if sector == "bank" else 0.0,
                    )
                )
        return companies

    @property
    def bank_reserves(self) -> float:
        return sum(
            bank.cash
            for bank in self.companies
            if bank.sector == "bank" and bank.active
        )

    @bank_reserves.setter
    def bank_reserves(self, balance: float) -> None:
        banks = [
            bank
            for bank in self.companies
            if bank.sector == "bank" and bank.active
        ]
        if not banks:
            return
        total = max(0.0, balance)
        current_total = sum(max(0.0, bank.cash) for bank in banks)
        for bank in banks:
            weight = (
                max(0.0, bank.cash) / current_total
                if current_total > 0.0
                else 1.0 / len(banks)
            )
            bank.cash = total * weight

    def step(self) -> MarketRecord:
        self.month += 1
        self.new_households_this_turn = 0
        self.resources.supplier_income = 0.0
        self.resources.supplier_employment = 0
        self.resources.household_technology_revenue = 0.0
        self.resources.household_technology_units = 0.0
        # salaire de référence basé sur productivité et tension du marché du travail, pas IPC
        self.wage_reference = self.config.starting_wage
        self.resources.recycled_materials += self.resources.recycling_pending
        self.resources.recycling_pending = 0.0
        for company in self.companies:
            if not company.active:
                continue
            company.previous_profit = company.profit
            company.previous_revenue = company.revenue
            company.revenue = 0.0
            company.expenses = 0.0
            company.units_sold = 0.0
            company.units_produced = 0.0
            company.stock_trade_volume = 0.0
            company.dividend_paid = 0.0
            company.capital_expenditure = 0.0
            company.property_cost_sold_this_turn = 0.0
            company.depreciation_this_turn = 0.0
            company.interest_paid_this_turn = 0.0
            company.principal_paid_this_turn = 0.0
            company.materials_supplied_this_turn = 0.0
            company.customer_revenue.clear()
            company.supplier_spending.clear()
            company.age_months += 1
            company.inventory *= 1.0 - self.config.inventory_spoilage_rate
            company.goods_inventory *= 1.0 - self.config.inventory_spoilage_rate
            previous_technology_asset = company.technology_asset_value
            technology_depreciation = company.tech_level * self.config.technology_depreciation_rate
            company.tech_level -= technology_depreciation
            company.technology_asset_value *= (
                1.0 - self.config.technology_depreciation_rate
            )
            technology_asset_depreciation = (
                previous_technology_asset - company.technology_asset_value
                if previous_technology_asset > 0.0
                else technology_depreciation
                * self.config.tech_unit_price
                / 0.03
            )
            previous_productive_capital = company.productive_capital_value
            company.production_capacity *= (
                1.0 - self.config.productive_capacity_depreciation_rate
            )
            company.productive_capital_value *= (
                1.0 - self.config.productive_capacity_depreciation_rate
            )
            productive_capital_depreciation = (
                previous_productive_capital - company.productive_capital_value
            )
            company.depreciation_this_turn = (
                technology_asset_depreciation + productive_capital_depreciation
            )
            company.expenses += company.depreciation_this_turn
        # Pas de cliquet de consommation : propension inchangée
        for person in self.people:
            person.dividend_income_this_turn = 0.0
        for person in self.people:
            person.technology_level *= (
                1.0 - self.config.technology_household_depreciation_rate
            )

        charge_inventory_holding_cost(
            self.companies, self.resources, self.config
        )
        complete_construction(self.companies, self.month, self.config)
        self.last_event, event_sector = self._generate_event()
        if self.last_event.startswith("Choc de matières premières"):
            self.resources.raw_materials *= 0.9

        tenant_demand = sum(not person.owns_home for person in self.people)
        rental_supply = sum(
            company.property_inventory
            for company in self.companies
            if company.active and company.sector == "real_estate"
        ) + sum(person.investment_homes for person in self.people)
        construction_pipeline = sum(
            len(company.construction_pipeline)
            for company in self.companies
            if company.active and company.sector == "real_estate"
        )
        housing_shortage = max(
            0, tenant_demand - rental_supply - construction_pipeline
        )
        company_debt_before_credit = {
            company.id: company.debt for company in self.companies
        }
        lent = request_operating_credit(
            self.companies,
            self.people,
            self.bank_reserves,
            self.config,
            housing_shortage,
            self.policy_rate,
        )
        self.bank_reserves = max(0.0, self.bank_reserves - lent)
        for company in self.companies:
            extension = max(
                0.0,
                company.debt - company_debt_before_credit.get(company.id, 0.0),
            )
            if extension > 0.0:
                self._book_bank_loan(company.id, extension)
        average_wage, unemployment = allocate_and_pay_labor(
            self.companies,
            self.people,
            self.wage_reference,
            self.config,
        )
        firm_employment = sum(
            person.employer_id is not None for person in self.people
        )
        supplier_employment, supplier_payroll = hire_service_workers(
            self.people,
            self.resources,
            self.wage_reference,
            self.config.supplier_wage_payout_rate,
        )
        total_employed_after_services = sum(
            person.employer_id is not None for person in self.people
        )
        if total_employed_after_services:
            average_wage = (
                average_wage * firm_employment + supplier_payroll
            ) / total_employed_after_services
        unemployment = (
            sum(person.employer_id is None for person in self.people)
            / len(self.people)
            if self.people
            else 0.0
        )
        elect_executives(
            self.companies, self.people, self.config, self.random
        )
        household_taxes, benefits_paid, self.government_balance = (
            collect_income_taxes_and_pay_benefits(
                self.people,
                self.government_balance,
                self.config.income_tax_rate,
                self.config.unemployment_benefit,
                unemployment,
                self.price_index,
                self.config.unemployment_benefit_cycle_sensitivity,
                self.config.income_tax_threshold,
                self.config.top_marginal_income_tax_rate,
            )
        )
        mortgage_debt_before_service = {
            person.id: person.mortgage_debt for person in self.people
        }
        mortgage_payments = service_mortgages(self.people)
        self.bank_reserves += mortgage_payments
        self._settle_mortgage_accounts(mortgage_debt_before_service)
        worker_skills = {
            person.id: (person.skill, person.technology_level)
            for person in self.people
        }

        food_demand = self._food_demand()
        forecast_goods_demand = self._goods_demand()
        self._update_raw_material_price(food_demand, forecast_goods_demand)
        baseline_price_growth = min(
            0.005, self.config.inflation_target * 0.5
        )
        food_demand_multiplier = (
            1.25 if self.last_event == "Pic de demande alimentaire" else 1.0
        )
        produce_food(
            self.companies,
            self.resources,
            self.config,
            food_demand,
            worker_skills,
        )
        food_supply = sum(
            company.units_produced
            for company in self.companies
            if company.active and company.sector == "food"
        )
        self.food_price = update_food_price(
            self.food_price,
            food_demand,
            food_supply,
            self.config.market_price_ceiling,
            baseline_growth_rate=baseline_price_growth,
            demand_multiplier=food_demand_multiplier,
        )
        apply_competitive_pricing(
            self.companies,
            self.food_price,
            self.goods_price,
            self.config.competitive_pricing_strength,
            self.config.inventory_discount_strength,
        )
        sold_food, food_revenue, unmet_food_demand = sell_food(
            self.companies, self.people, self.food_price, self.config
        )

        goods_demand = self._goods_demand()
        produce_consumer_goods(
            self.companies,
            self.resources,
            self.config,
            goods_demand,
            worker_skills,
        )
        goods_supply = sum(
            company.units_produced
            for company in self.companies
            if company.active and company.sector == "goods"
        )
        self.goods_price = update_food_price(
            self.goods_price,
            goods_demand,
            goods_supply,
            self.config.market_price_ceiling,
            baseline_growth_rate=baseline_price_growth,
            demand_multiplier=(
                1.15 if self.last_event == "Lancement de nouveaux produits" else 1.0
            ),
        )
        apply_competitive_pricing(
            self.companies,
            self.food_price,
            self.goods_price,
            self.config.competitive_pricing_strength,
            self.config.inventory_discount_strength,
        )
        sold_goods, goods_revenue, unmet_goods_demand = sell_consumer_goods(
            self.companies, self.people, self.goods_price, self.config
        )
        collect_recyclable_materials(
            self.companies, self.resources, self.config
        )

        trade_technology(
            self.companies, self.resources, self.config, self.people
        )
        housing_units_built = build_housing(
            self.companies,
            self.resources,
            self.people,
            self.month,
            self.config,
            housing_shortage,
        )
        mortgage_debt_before_loans = {
            person.id: person.mortgage_debt for person in self.people
        }
        _, mortgage_loans = buy_homes(
            self.companies,
            self.people,
            self.config.housing_price,
            self.config.housing_build_cost,
            self.config,
            self.bank_reserves,
        )
        self.bank_reserves = max(0.0, self.bank_reserves - mortgage_loans)
        for person in self.people:
            extension = max(
                0.0,
                person.mortgage_debt
                - mortgage_debt_before_loans.get(person.id, 0.0),
            )
            if extension > 0.0:
                self._book_bank_loan(f"mortgage:{person.id}", extension)
        rental_revenue = allocate_housing_and_collect_rent(
            self.companies,
            self.people,
            self.rent,
            self.config.household_rent_income_share,
        )
        maintain_housing(
            self.companies, self.people, self.resources, self.config
        )
        self._adjust_rent()
        previous_price_index = self.price_index
        self.price_index = self._consumer_price_index()
        inflation_rate = (
            self.price_index / max(previous_price_index, 1.0) - 1.0
        )

        company_debt_before_service = {
            company.id: company.debt for company in self.companies
        }
        interest_received = service_company_debt(self.companies, self.config)
        self.bank_reserves += interest_received
        self._settle_company_loan_accounts(company_debt_before_service)
        for company in self.companies:
            if company.active:
                company.profit = company.revenue - company.expenses
        adjust_profit_sharing_wages(
            self.companies,
            self.people,
            self.wage_reference,
            self.config.executive_bonus_rate,
            self.config.wage_productivity_share,
            self.config.loss_wage_adjustment_strength,
            unemployment,
            self.config.wage_unemployment_sensitivity,
        )
        research_investment = invest_in_innovation(
            self.companies, self.random, self.resources
        )
        corporate_taxes = tax_company_profits(
            self.companies, self.config.corporate_tax_rate
        )
        self.government_balance += corporate_taxes
        for company in self.companies:
            if company.active:
                company.profit = company.revenue - company.expenses
        # dividend floor pour éviter l'effondrement complet
        dividends_paid = distribute_dividends(
            self.companies,
            self.people,
            self.config.dividend_payout_rate,
        )
        for company in self.companies:
            if company.active:
                company.profit = company.revenue - company.expenses
                if company.sector == "bank":
                    company.bank_equity = max(
                        0.0,
                        company.bank_equity
                        + company.profit
                        - company.dividend_paid,
                    )

        secondary_volume = update_prices_and_trade(
            self.companies, self.people, event_sector, self.config
        )
        acquisitions = consolidate_market(
            self.companies, self.people, self.config, self.random, self.month
        )
        self.bank_reserves, bankruptcies = resolve_distressed_companies(
            self.companies,
            self.people,
            self.bank_reserves,
            self.config,
            self.random,
        )
        self._write_off_defaulted_bank_loans()
        self.total_defaults += bankruptcies
        new_companies, _, startups = create_household_startups(
            self.companies,
            self.people,
            self.month,
            self.bank_reserves,
            self.config,
            self.random,
        )
        self.companies.extend(new_companies)
        production_capacity_investment = invest_in_production_capacity(
            self.companies,
            {"food": unmet_food_demand, "goods": unmet_goods_demand},
            self.config,
            self.resources,
        )
        self._grow_population()

        self.total_tax_revenue += household_taxes + corporate_taxes
        self.total_benefits_paid += benefits_paid
        # dépenses publiques pour maintenir un solde public proche de zéro sur le long terme
        if self.government_balance > 0:
            public_spending = min(self.government_balance * 0.5, self.government_balance)
            self.government_balance -= public_spending
            self.resources.market_cash = max(0.0, self.resources.market_cash + public_spending)
        total_revenue = sum(company.revenue for company in self.companies if company.active)
        total_profit = sum(company.profit for company in self.companies if company.active)
        bank_interest_income = sum(
            company.revenue
            for company in self.companies
            if company.active and company.sector == "bank"
        )
        occupied = sum(person.rental_owner_id is not None for person in self.people)
        owner_occupied = sum(person.owns_home for person in self.people)
        nominal_gdp = (
            food_revenue
            + goods_revenue
            + self.resources.household_technology_revenue
            + rental_revenue
            + owner_occupied * self.rent
            + housing_units_built * self.config.housing_build_cost
            + bank_interest_income
            + production_capacity_investment
            + research_investment
        )
        real_gdp = (
            sold_food * self.config.starting_food_price
            + sold_goods * self.config.starting_goods_price
            + self.resources.household_technology_units
            * self.config.tech_unit_price
            * self.config.technology_household_price_fraction
            + rental_revenue
            * self.config.starting_rent
            / max(self.rent, 1.0)
            + owner_occupied * self.config.starting_rent
            + housing_units_built * self.config.housing_build_cost
            + bank_interest_income
            + production_capacity_investment
            + research_investment
        )
        consumer_revenue = food_revenue + goods_revenue
        active_housing = sum(
            company.property_inventory
            for company in self.companies
            if company.active and company.sector == "real_estate"
        ) + sum(person.investment_homes for person in self.people)
        record = MarketRecord(
            month=self.month,
            food_price=self.food_price,
            average_wage=average_wage,
            food_sold=sold_food,
            unemployment=unemployment,
            housing_rent=self.rent,
            total_revenue=total_revenue,
            total_profit=total_profit,
            event=self.last_event,
            goods_price=self.goods_price,
            goods_sold=sold_goods,
            unmet_food_demand=unmet_food_demand,
            unmet_goods_demand=unmet_goods_demand,
            tax_revenue=household_taxes + corporate_taxes,
            benefits_paid=benefits_paid,
            dividends_paid=dividends_paid,
            secondary_volume=secondary_volume,
            homes_occupied=occupied,
            vacancies=max(0, active_housing - occupied),
            acquisitions=acquisitions,
            startups=startups,
            bankruptcies=bankruptcies,
            bank_reserves=self.bank_reserves,
            bank_loan_portfolio=sum(
                company.debt for company in self.companies if company.active
            )
            + sum(person.mortgage_debt for person in self.people),
            bank_equity=sum(
                company.bank_equity
                for company in self.companies
                if company.active and company.sector == "bank"
            ),
            bank_interest_income=bank_interest_income,
            housing_construction=(
                housing_units_built * self.config.housing_build_cost
            ),
            resource_market_cash=self.resources.market_cash,
            employed_count=sum(person.employer_id is not None for person in self.people),
            household_income=sum(person.income_this_turn for person in self.people),
            household_spending=sum(person.expenses_this_turn for person in self.people),
            raw_materials_remaining=self.resources.raw_materials,
            recycled_materials_remaining=self.resources.recycled_materials,
            raw_material_price=self.resources.raw_material_price,
            consumer_price_index=self.price_index,
            inflation_rate=inflation_rate,
            real_average_wage=average_wage * 100.0 / max(self.price_index, 1.0),
            real_household_income=sum(
                person.income_this_turn for person in self.people
            )
            * 100.0
            / max(self.price_index, 1.0),
            nominal_gdp=nominal_gdp,
            real_gdp=real_gdp,
            household_technology_revenue=self.resources.household_technology_revenue,
            household_technology_units=self.resources.household_technology_units,
            food_inventory=sum(
                company.inventory
                for company in self.companies
                if company.active and company.sector == "food"
            ),
            goods_inventory=sum(
                company.goods_inventory
                for company in self.companies
                if company.active and company.sector == "goods"
            ),
            technology_inventory=sum(
                company.tech_inventory
                for company in self.companies
                if company.active and company.sector == "technology"
            ),
            food_produced=sum(
                company.units_produced
                for company in self.companies
                if company.active and company.sector == "food"
            ),
            goods_produced=sum(
                company.units_produced
                for company in self.companies
                if company.active and company.sector == "goods"
            ),
            production_capacity_investment=production_capacity_investment,
            new_households=self.new_households_this_turn,
            population_count=len(self.people),
            supplier_income=supplier_payroll,
            supplier_employment=supplier_employment,
            household_tax_revenue=household_taxes,
            policy_rate=self.policy_rate,
            mortgage_debt=sum(person.mortgage_debt for person in self.people),
            company_prices={
                company.id: company.stock_price if company.active else 0.0
                for company in self.companies
            },
            sector_employment={
                **{
                    sector: sum(
                        len(company.employees)
                        for company in self.companies
                        if company.active and company.sector == sector
                    )
                    for sector, _ in SECTORS
                    if sector != "services"
                },
                "services": supplier_employment,
            },
            sector_revenue={
                **{
                    sector: sum(
                        company.revenue
                        for company in self.companies
                        if company.active and company.sector == sector
                    )
                    for sector, _ in SECTORS
                    if sector != "services"
                },
                "services": supplier_payroll,
            },
            sector_profit={
                sector: sum(
                    company.profit
                    for company in self.companies
                    if company.active and company.sector == sector
                )
                for sector, _ in SECTORS
                if sector != "services"
            },
            sector_average_wage={
                **{
                    sector: (
                        sum(
                            company.wage_bill
                            for company in self.companies
                            if company.active and company.sector == sector
                        )
                        / max(
                            1,
                            sum(
                                len(company.employees)
                                for company in self.companies
                                if company.active and company.sector == sector
                            ),
                        )
                    )
                    for sector, _ in SECTORS
                    if sector != "services"
                },
                "services": (
                    supplier_payroll / supplier_employment
                    if supplier_employment
                    else 0.0
                ),
            },
            sector_market_share={
                "food": food_revenue / consumer_revenue
                if consumer_revenue > 0.0
                else 0.0,
                "goods": goods_revenue / consumer_revenue
                if consumer_revenue > 0.0
                else 0.0,
            },
        )
        enrich_wealth_record(
            record,
            self.people,
            self.companies,
            self.config,
            self.price_index,
        )
        self.history.append(record)
        self._adjust_policy_rate(inflation_rate, unemployment)
        return record

    def _book_bank_loan(self, borrower_id: str, amount: float) -> None:
        banks = [
            company
            for company in self.companies
            if company.active and company.sector == "bank"
        ]
        if amount <= 0.0 or not banks:
            return
        banks.sort(
            key=lambda bank: (
                sum(bank.bank_loan_accounts.values()),
                bank.id,
            )
        )
        for bank in banks:
            allocation = amount / len(banks)
            bank.bank_loan_accounts[borrower_id] = (
                bank.bank_loan_accounts.get(borrower_id, 0.0) + allocation
            )

    def _settle_company_loan_accounts(
        self, previous_debts: dict[str, float]
    ) -> None:
        companies_by_id = {company.id: company for company in self.companies}
        for borrower_id, previous_debt in previous_debts.items():
            borrower = companies_by_id.get(borrower_id)
            if borrower is None:
                continue
            if borrower.sector == "bank":
                continue
            lenders = [
                bank
                for bank in self.companies
                if bank.sector == "bank"
                and bank.bank_loan_accounts.get(borrower_id, 0.0) > 0.0
            ]
            total_booked = sum(
                bank.bank_loan_accounts[borrower_id] for bank in lenders
            )
            if not lenders or total_booked <= 0.0:
                continue
            shares = {
                bank.id: bank.bank_loan_accounts[borrower_id] / total_booked
                for bank in lenders
            }
            interest_paid = borrower.interest_paid_this_turn
            unpaid_interest = max(
                0.0,
                borrower.debt
                - previous_debt
                + borrower.principal_paid_this_turn,
            )
            for bank in lenders:
                share = shares[bank.id]
                bank.revenue += (interest_paid + unpaid_interest) * share
                bank.bank_loan_accounts[borrower_id] = max(
                    0.0, borrower.debt * share
                )

    def _settle_mortgage_accounts(
        self, previous_debts: dict[str, float]
    ) -> None:
        for person in self.people:
            previous_debt = previous_debts.get(person.id, 0.0)
            if previous_debt <= 0.0:
                continue
            interest_accrued = previous_debt * person.mortgage_rate
            lenders = [
                bank
                for bank in self.companies
                if bank.sector == "bank"
                and bank.bank_loan_accounts.get(f"mortgage:{person.id}", 0.0) > 0.0
            ]
            total_booked = sum(
                bank.bank_loan_accounts[f"mortgage:{person.id}"]
                for bank in lenders
            )
            if total_booked <= 0.0:
                continue
            for bank in lenders:
                share = (
                    bank.bank_loan_accounts[f"mortgage:{person.id}"]
                    / total_booked
                )
                bank.bank_loan_accounts[f"mortgage:{person.id}"] = (
                    person.mortgage_debt * share
                )
                bank.revenue += interest_accrued * share

    def _write_off_defaulted_bank_loans(self) -> None:
        defaulted_ids = {
            company.id
            for company in self.companies
            if company.sector != "bank" and not company.active
        }
        for borrower_id in defaulted_ids:
            lenders = [
                bank
                for bank in self.companies
                if bank.sector == "bank"
                and bank.bank_loan_accounts.get(borrower_id, 0.0) > 0.0
            ]
            exposure = sum(
                bank.bank_loan_accounts[borrower_id] for bank in lenders
            )
            if exposure <= 0.0:
                continue
            borrower = next(
                (company for company in self.companies if company.id == borrower_id),
                None,
            )
            loss = min(exposure, borrower.default_loss if borrower else exposure)
            for bank in lenders:
                share = bank.bank_loan_accounts[borrower_id] / exposure
                bank.default_loss += loss * share
                bank.expenses += loss * share
                bank.bank_equity -= loss * share
                bank.bank_loan_accounts.pop(borrower_id, None)

        banks = [
            bank
            for bank in self.companies
            if bank.sector == "bank" and bank.active and bank.bank_equity <= 0.0
        ]
        for failed_bank in banks:
            receivers = [
                bank
                for bank in self.companies
                if bank.sector == "bank"
                and bank.active
                and bank.id != failed_bank.id
            ]
            if not receivers:
                continue
            receiver = min(
                receivers,
                key=lambda bank: sum(bank.bank_loan_accounts.values()),
            )
            receiver.cash += failed_bank.cash
            receiver.bank_equity += max(0.0, failed_bank.bank_equity)
            for borrower_id, balance in failed_bank.bank_loan_accounts.items():
                receiver.bank_loan_accounts[borrower_id] = (
                    receiver.bank_loan_accounts.get(borrower_id, 0.0) + balance
                )
            failed_bank.cash = 0.0
            failed_bank.bank_loan_accounts.clear()
            failed_bank.active = False
            failed_bank.stock_price = 0.0
            failed_bank.shares_outstanding = 0.0
            failed_bank.treasury_shares = 0.0
            for owner in [*self.people, *self.companies]:
                owner.shares.pop(failed_bank.id, None)

    def _adjust_policy_rate(
        self,
        inflation_rate: float,
        unemployment_rate: float,
    ) -> None:
        inflation_gap = inflation_rate - self.config.inflation_target
        unemployment_gap = max(0.0, unemployment_rate - 0.08)
        self.policy_rate = max(
            0.0001,
            min(
                0.04,
                self.policy_rate
                + self.config.policy_rate_inflation_sensitivity * inflation_gap
                - self.config.policy_rate_unemployment_sensitivity
                * unemployment_gap,
            ),
        )

    def _food_demand(self) -> float:
        return sum(
            min(
                person.cash,
                max(
                    0.0,
                    person.income_this_turn
                    * self.config.food_income_budget_share
                    + person.cash * self.config.food_cash_draw_rate,
                ),
            )
            * person.consumption_propensity
            / max(self.food_price * 1.16, 0.01)
            for person in self.people
        )

    def _goods_demand(self) -> float:
        return sum(
            min(
                person.cash,
                max(
                    0.0,
                    person.income_this_turn
                    * self.config.goods_income_budget_share
                    + person.cash * self.config.goods_cash_draw_rate,
                ),
            )
            * person.consumption_propensity
            / max(self.goods_price * 1.16, 0.01)
            for person in self.people
        )

    def _grow_population(self) -> None:
        population_cap = int(
            self.initial_population_size
            * (1.0 + self.config.maximum_population_growth)
        )
        if (
            self.config.monthly_population_growth_rate <= 0.0
            or len(self.people) >= population_cap
        ):
            return
        self.population_growth_progress += (
            len(self.people) * self.config.monthly_population_growth_rate
        )
        while (
            self.population_growth_progress >= 1.0
            and len(self.people) < population_cap
        ):
            person_number = len(self.people) + 1
            newcomer = Person(
                f"p{person_number - 1:04d}",
                f"Nouveau ménage {person_number}",
                0.0,
                skill=self.random.uniform(0.55, 1.05),
                risk_tolerance=self.random.random(),
                consumption_propensity=self.random.uniform(
                    1.0 - self.config.household_propensity_variance,
                    1.0 + self.config.household_propensity_variance,
                ),
                quality_preference=self.random.uniform(0.65, 1.35),
                technology_level=0.0,
            )
            self.people.append(newcomer)
            self.population_growth_progress -= 1.0
            self.population_job_progress += self.config.target_employment_rate
            self.new_households_this_turn += 1

            while self.population_job_progress >= 1.0:
                production_firms = [
                    company
                    for company in self.companies
                    if company.active and company.sector in {"food", "goods"}
                ]
                if production_firms:
                    best_candidate = max(
                        production_firms,
                        key=lambda company: (
                            company.previous_profit
                            / max(1, company.target_employees),
                            -len(company.employees),
                            company.id,
                        ),
                    )
                    best_candidate.target_employees += 1
                self.population_job_progress -= 1.0

    def _update_raw_material_price(
        self,
        food_demand: float,
        goods_demand: float,
    ) -> None:
        worker_skills = {
            person.id: (person.skill, person.technology_level)
            for person in self.people
        }
        food_capacity = sum(
            effective_worker_count(company, worker_skills)
            * self.config.food_productivity
            * company.productivity_trait
            * (1.0 + min(company.tech_level, 10.0) * 0.04)
            + company.production_capacity
            for company in self.companies
            if company.active and company.sector == "food"
        )
        goods_capacity = sum(
            effective_worker_count(company, worker_skills)
            * self.config.goods_productivity
            * company.productivity_trait
            * (1.0 + min(company.tech_level, 10.0) * 0.06)
            + company.production_capacity
            for company in self.companies
            if company.active and company.sector == "goods"
        )
        extraction_capacity = sum(
            effective_worker_count(company, worker_skills)
            * self.config.raw_material_extraction_productivity
            for company in self.companies
            if company.active and company.sector == "materials"
        )
        raw_demand = min(food_demand * 1.05, food_capacity) + 1.5 * min(
            goods_demand * 1.05, goods_capacity
        )
        extractable_virgin = min(self.resources.raw_materials, extraction_capacity)
        raw_supply = extractable_virgin + self.resources.recycled_materials
        updated_price = update_food_price(
            self.resources.raw_material_price,
            raw_demand,
            raw_supply,
            self.config.market_price_ceiling,
        )
        suppliers = [
            company
            for company in self.companies
            if company.active and company.sector == "materials"
        ]
        virgin_demand = max(0.0, raw_demand - self.resources.recycled_materials)
        minimum_price = 1.0
        if extraction_capacity > 0.0:
            viable_sales = min(virgin_demand, extractable_virgin)
            for supplier in suppliers:
                supplier_capacity = (
                    effective_worker_count(supplier, worker_skills)
                    * self.config.raw_material_extraction_productivity
                )
                expected_sales = (
                    viable_sales * supplier_capacity / extraction_capacity
                )
                if expected_sales > 0.0:
                    minimum_price = max(
                        minimum_price,
                        supplier.wage_bill / expected_sales
                        + self.config.raw_material_extraction_cost,
                    )
        minimum_price = min(self.config.market_price_ceiling, minimum_price)
        self.resources.raw_material_price = max(minimum_price, updated_price)

    def _adjust_rent(self) -> None:
        rental_supply = sum(
            company.property_inventory
            for company in self.companies
            if company.active and company.sector == "real_estate"
        ) + sum(person.investment_homes for person in self.people)
        tenants = sum(not person.owns_home for person in self.people)
        housing_pressure = tenants / max(rental_supply, 1)
        incomes = sorted(
            person.income_this_turn
            for person in self.people
            if person.income_this_turn > 0.0
        )
        median_income = incomes[len(incomes) // 2] if incomes else self.wage_reference
        affordability_ratio = self.rent / max(median_income, 1.0)
        affordability_adjustment = (
            0.35 - affordability_ratio
        ) * self.config.rent_affordability_weight
        rent_change = max(
            -0.035,
            min(
                0.035,
                (housing_pressure - 0.85) * 0.025
                + max(-0.03, min(0.03, affordability_adjustment)),
            ),
        )
        self.rent = max(
            self.config.starting_rent * 0.4,
            min(self.config.starting_rent * 4.0, self.rent * (1.0 + rent_change)),
        )

    def _consumer_price_index(self) -> float:
        weights = (
            self.config.cpi_food_weight,
            self.config.cpi_goods_weight,
            self.config.cpi_rent_weight,
        )
        total_weight = sum(weights)
        if total_weight <= 0.0:
            return 100.0
        price_ratios = (
            self.food_price / self.config.starting_food_price,
            self.goods_price / self.config.starting_goods_price,
            self.rent / self.config.starting_rent,
        )
        return (
            100.0
            * sum(
                weight * ratio
                for weight, ratio in zip(weights, price_ratios)
            )
            / total_weight
        )

    def _generate_event(self) -> tuple[str, str | None]:
        if self.random.random() >= 0.12:
            return "Aucun événement", None
        sector, _ = self.random.choice(
            tuple(item for item in SECTORS if item[0] not in {"bank", "services"})
        )
        descriptions = {
            "food": "Pic de demande alimentaire",
            "technology": "Innovation technologique",
            "goods": "Lancement de nouveaux produits",
            "real_estate": "Demande immobilière soutenue",
            "materials": "Variation de la demande en matières premières",
        }
        if sector == "food" and self.random.random() < 0.5:
            return "Choc de matières premières", sector
        return descriptions[sector], sector

    def company_rows(self) -> list[dict[str, object]]:
        rows: list[dict[str, object]] = []
        for company in self.companies:
            wage_average = company.wage_bill / len(company.employees) if company.employees else 0.0
            holdings = [
                (
                    f"{self.company_name(company_id)}: {quantity:.1f} actions "
                    f"({quantity / max(self._company_shares(company_id), 1.0):.1%})"
                )
                for company_id, quantity in sorted(company.shares.items())
            ]
            loan_portfolio = sum(company.bank_loan_accounts.values())
            rows.append(
                {
                    "_id": company.id,
                    "Entreprise": company.name,
                    "Secteur": dict(SECTORS)[company.sector],
                    "Statut": "Active" if company.active else "Absorbée / fermée",
                    "CEO": self.person_name(company.executive_id),
                    "Employés": len(company.employees),
                    "Salaire moyen": wage_average,
                    "Chiffre d'affaires": company.revenue,
                    "Bénéfice": company.profit,
                    "Trésorerie": company.cash,
                    "Dettes": company.debt,
                    "Dividendes": company.dividend_paid,
                    "Participations": ", ".join(holdings) or "—",
                    "Portefeuille de prêts": loan_portfolio,
                    "Emprunteurs": len(company.bank_loan_accounts),
                    "Cours": company.stock_price,
                    "Fortune nette": self.company_wealth(company),
                    "Qualité": company.quality_trait,
                    "Stock alimentaire": company.inventory if company.sector == "food" else 0.0,
                    "Valeur du stock alimentaire": (
                        company.inventory * self.config.food_input_cost
                        if company.sector == "food"
                        else 0.0
                    ),
                    "Stock de biens": company.goods_inventory if company.sector == "goods" else 0.0,
                    "Stock technologique": company.tech_inventory if company.sector == "technology" else 0.0,
                    "Production mensuelle": company.units_produced,
                    "Unités vendues": company.units_sold,
                    "Capacité supplémentaire": company.production_capacity,
                    "Niveau technologique": company.tech_level,
                    "Traits": (
                        f"Productivité {company.productivity_trait:.2f} · "
                        f"Risque {company.risk_tolerance:.2f} · "
                        f"Prix {company.pricing_aggression:.2f}"
                    ),
                    "Immobilier en stock": company.property_inventory if company.active else 0,
                    "Construction (mois)": (
                        str(min(company.construction_pipeline) - self.month)
                        if company.construction_pipeline
                        else "—"
                    ),
                }
            )
        return rows

    def company_name(self, company_id: str | None) -> str:
        if company_id is None:
            return "—"
        if company_id == "services":
            return "Services aux entreprises"
        return next((company.name for company in self.companies if company.id == company_id), company_id)

    def person_name(self, person_id: str | None) -> str:
        if person_id is None:
            return "Aucun"
        return next((person.name for person in self.people if person.id == person_id), person_id)

    def company_wealth(self, company: Company) -> float:
        from economy.wealth import company_net_worth

        return company_net_worth(company, self.companies, self.config)

    def household_wealth(self, person: Person) -> float:
        from economy.wealth import household_net_worth

        return household_net_worth(person, self.companies, self.config)

    def household_leaderboard(self, limit: int = 10) -> list[dict[str, object]]:
        households, _ = wealth_leaderboards(
            self.people, self.companies, self.config, limit
        )
        return households

    def company_leaderboard(self, limit: int = 10) -> list[dict[str, object]]:
        _, companies = wealth_leaderboards(
            self.people, self.companies, self.config, limit
        )
        return companies

    def population_summary(self) -> dict[str, float]:
        employed = sum(person.employer_id is not None for person in self.people)
        return {
            "employed": float(employed),
            "unemployed": float(len(self.people) - employed),
            "cash": sum(person.cash for person in self.people),
            "owners": float(sum(person.owns_home for person in self.people)),
            "renters": float(sum(person.rental_owner_id is not None for person in self.people)),
            "food": sum(person.last_food_bought for person in self.people),
            "goods": sum(person.last_goods_bought for person in self.people),
            "average_cash": (
                sum(person.cash for person in self.people) / len(self.people) if self.people else 0.0
            ),
            "home_satisfaction": (
                sum(person.owns_home or person.rental_owner_id is not None for person in self.people)
                / len(self.people)
                if self.people
                else 0.0
            ),
        }

    def household_rows(self, limit: int = 25) -> list[dict[str, object]]:
        return [
            {
                "_id": person.id,
                "Ménage": person.name,
                "Fortune nette": self.household_wealth(person),
                "Trésorerie": person.cash,
                "Employeur": self.company_name(person.employer_id),
                "CEO": any(company.executive_id == person.id for company in self.companies),
                "Revenu du mois": person.income_this_turn,
                "Nourriture achetée": person.last_food_bought,
                "Biens achetés": person.last_goods_bought,
                "Compétence": person.skill,
                "Expérience (mois)": person.employer_tenure,
                "Dépenses cumulées": person.cumulative_expenses,
                "Logement": "Propriétaire" if person.owns_home else (
                    "Locataire" if person.rental_owner_id else "Sans logement loué"
                ),
                "Dette immobilière": person.mortgage_debt,
                "Mensualité du prêt": person.mortgage_payment,
                "Actions détenues": ", ".join(
                    f"{self.company_name(company_id)} ({shares:.1f})"
                    for company_id, shares in person.shares.items()
                ) or "—",
            }
            for person in sorted(
                self.people,
                key=lambda household: self.household_wealth(household),
                reverse=True,
            )[:limit]
        ]

    def household_profile(self, person_id: str) -> dict[str, object] | None:
        person = next((household for household in self.people if household.id == person_id), None)
        if person is None:
            return None
        return {
            "person": person,
            "wealth": self.household_wealth(person),
            "shares": [
                {
                    "Entreprise": self.company_name(company_id),
                    "Actions": shares,
                    "Part du capital": (
                        shares / self._company_shares(company_id)
                        if self._company_shares(company_id) > 0.0
                        else 0.0
                    ),
                    "Valeur": shares * self._company_price(company_id),
                }
                for company_id, shares in person.shares.items()
            ],
        }

    def company_profile(self, company_id: str) -> Company | None:
        return next((company for company in self.companies if company.id == company_id), None)

    def _company_price(self, company_id: str) -> float:
        company = next((firm for firm in self.companies if firm.id == company_id), None)
        return company.stock_price if company and company.active else 0.0

    def _company_shares(self, company_id: str) -> float:
        company = next(
            (firm for firm in self.companies if firm.id == company_id), None
        )
        return company.shares_outstanding if company else 0.0

    def resource_summary(self) -> dict[str, float]:
        company_debt = sum(
            company.debt for company in self.companies if company.active
        )
        mortgage_debt = sum(person.mortgage_debt for person in self.people)
        return {
            "Matières premières restantes": self.resources.raw_materials,
            "Matières recyclées disponibles": self.resources.recycled_materials,
            "Matières en cours de récupération": self.resources.recycling_pending,
            "Prix des matières premières": self.resources.raw_material_price,
            "Terrains restants": float(self.resources.land_units),
            "Connaissances restantes": self.resources.knowledge,
            "Actions encore disponibles": sum(
                company.treasury_shares for company in self.companies if company.active
            ),
            "Prix d'un logement": self.config.housing_price,
            "Prix des biens courants": self.goods_price,
            "Trésorerie publique": self.government_balance,
            "Trésorerie bancaire": self.bank_reserves,
            "Encours des prêts bancaires": company_debt + mortgage_debt,
            "Prêts aux entreprises": company_debt,
            "Prêts immobiliers": mortgage_debt,
            "Fonds des fournisseurs de ressources et services": self.resources.market_cash,
            "Fonds propres bancaires": sum(
                company.bank_equity
                for company in self.companies
                if company.sector == "bank" and company.active
            ),
            "Dettes des entreprises": company_debt,
            "Impôts cumulés": self.total_tax_revenue,
            "Aides cumulées": self.total_benefits_paid,
            "Entreprises actives": float(sum(company.active for company in self.companies)),
        }
