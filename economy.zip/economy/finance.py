from __future__ import annotations

import random

from economy.models import Company, Person, SimulationConfig
from economy.labor import workforce_targets


def request_operating_credit(
    companies: list[Company],
    people: list[Person],
    bank_reserves: float,
    config: SimulationConfig,
    housing_shortage: int = 0,
    policy_rate: float | None = None,
) -> float:
    current_policy_rate = (
        config.loan_interest_rate if policy_rate is None else max(0.0, policy_rate)
    )
    people_by_id = {person.id: person for person in people}
    lent = 0.0
    remaining_housing_shortage = max(0, housing_shortage)
    for company in companies:
        if (
            not company.active
            or company.sector == "bank"
            or bank_reserves <= 0.0
        ):
            continue
        executive = people_by_id.get(company.executive_id or "")
        risk = executive.risk_tolerance if executive else company.risk_tolerance
        experience = min(company.ceo_experience, 10) / 10.0
        leverage_limit = config.maximum_loan_leverage * (0.35 + risk * 0.65)
        collateral = max(
            0.0,
            company.cash
            + company.property_inventory * config.housing_price
            + company.construction_in_progress
            + company.inventory * config.starting_food_price
            + company.goods_inventory * config.starting_goods_price,
        )
        operating_reserve = company.target_employees * company.wage_offer * 1.25
        housing_units = (
            min(1, remaining_housing_shortage)
            if company.sector == "real_estate"
            else 0
        )
        # élargir le collatéral aux actifs productifs et technologiques
        collateral = max(
            0.0,
            company.cash
            + company.property_inventory * config.housing_price
            + company.construction_in_progress
            + company.inventory * config.starting_food_price
            + company.goods_inventory * config.starting_goods_price
            + company.productive_capital_value
            + company.technology_asset_value,
        )
        collateral_capacity = max(0.0, collateral * leverage_limit - company.debt)
        revenue_capacity = max(
            max(
                2.0 * operating_reserve,
                housing_units * config.housing_build_cost + operating_reserve,
            ),
            company.previous_revenue
            * config.maximum_debt_service_ratio
            / max(current_policy_rate, 0.0001),
        )
        borrowing_capacity = min(
            collateral_capacity,
            max(0.0, revenue_capacity - company.debt),
        )
        operating_gap = max(0.0, operating_reserve - company.cash)
        construction_gap = (
            max(
                0.0,
                housing_units * config.housing_build_cost
                + operating_reserve
                - company.cash,
            )
            if housing_units
            else 0.0
        )
        # besoin d'investissement pour faire face à un sous-emploi de trésorerie
        wage_reserve = company.target_employees * company.wage_offer * 1.5
        cash_buffer_target = wage_reserve + company.debt * 0.02
        investment_need = max(0.0, cash_buffer_target - company.cash)
        # favoriser les entreprises avec demande non satisfaite et faible ratio trésorerie/salaire
        demand_factor = 1.0
        if company.sector in {"food", "goods"}:
            demand_factor = max(1.0, 1.5 - company.cash / max(wage_reserve, 1.0))
        # augmenter la sensibilité au risque pour différencier les prêts
        confidence = max(0.25, min(1.0, 0.45 + experience * 0.3 + risk * 0.35))
        # pénalité pour faible expérience
        risk_adjust = 1.0 + (1.0 - max(0.0, min(1.0, experience))) * 0.15 * risk
        # base loan driven by operating gap and risk, with investment need as supplement
        base_loan = operating_gap * confidence * risk_adjust
        investment_loan = investment_need * demand_factor * 0.3  # réduit pour ne pas capper
        loan = min(
            max(base_loan, construction_gap, investment_loan),
            borrowing_capacity,
            bank_reserves,
        )
        if loan <= 0.0:
            continue
        experience = max(0.0, min(1.0, experience))
        risk_spread = config.credit_risk_spread * (
            0.5 * max(0.0, min(1.0, risk))
            + 0.5 * (1.0 - experience)
        )
        new_loan_rate = current_policy_rate + risk_spread
        previous_debt_rate = company.debt_interest_rate
        if previous_debt_rate is None:
            previous_debt_rate = config.loan_interest_rate
        company.debt_interest_rate = (
            (company.debt * previous_debt_rate + loan * new_loan_rate)
            / (company.debt + loan)
        )
        company.cash += loan
        company.debt += loan
        bank_reserves -= loan
        lent += loan
        remaining_housing_shortage -= housing_units
    return lent


def service_company_debt(
    companies: list[Company],
    config: SimulationConfig,
) -> float:
    cash_received = 0.0
    for company in companies:
        if not company.active or company.debt <= 0.0:
            continue
        company.interest_paid_this_turn = 0.0
        company.principal_paid_this_turn = 0.0
        interest_rate = (
            company.debt_interest_rate
            if company.debt_interest_rate is not None
            else config.loan_interest_rate
        )
        interest = company.debt * interest_rate
        interest_paid = min(company.cash, interest)
        company.cash -= interest_paid
        company.expenses += interest
        company.interest_paid_this_turn = interest_paid
        cash_received += interest_paid
        unpaid_interest = interest - interest_paid
        company.debt += unpaid_interest
        free_cash = max(
            0.0,
            company.cash - company.target_employees * company.wage_offer * 1.5,
        )
        principal = min(company.debt, free_cash * 0.12)
        if principal > 0.0:
            company.debt -= principal
            company.cash -= principal
            company.principal_paid_this_turn = principal
            cash_received += principal
    return cash_received


def create_household_startups(
    companies: list[Company],
    people: list[Person],
    month: int,
    bank_reserves: float,
    config: SimulationConfig,
    rng: random.Random,
) -> tuple[list[Company], float, int]:
    existing_counts: dict[str, int] = {}
    for company in companies:
        existing_counts[company.sector] = existing_counts.get(company.sector, 0) + 1

    created: list[Company] = []
    sectors = ("food", "goods", "technology", "real_estate", "materials")
    targets = workforce_targets(config)
    
    # 1. Startups classiques fondées par des ménages disposant d'épargne
    for person in sorted(people, key=lambda household: household.cash, reverse=True):
        if person.founded_company or person.cash < config.startup_threshold:
            continue
        if rng.random() >= config.company_founder_probability:
            continue
        sector = min(sectors, key=lambda item: (existing_counts.get(item, 0), item))
        name = f"Nouvelle {sector} {month}-{len(created) + 1}"
        contribution = person.cash * config.startup_investment_fraction
        person.cash -= contribution
        person.founded_company = True
        shares_outstanding = 1000.0
        company = Company(
            id=f"startup_{month}_{len(created) + 1}_{person.id}",
            name=name,
            sector=sector,
            cash=contribution,
            wage_offer=config.starting_wage * 0.8,
            target_employees=targets[sector],
            price=config.starting_food_price if sector == "food" else config.starting_goods_price,
            stock_price=max(1.0, contribution / shares_outstanding),
            previous_stock_price=max(1.0, contribution / shares_outstanding),
            shares_outstanding=shares_outstanding,
            treasury_shares=0.0,
            productivity_trait=rng.uniform(0.75, 1.35),
            quality_trait=rng.uniform(
                1.0 - config.quality_trait_variance,
                1.0 + config.quality_trait_variance,
            ),
            risk_tolerance=person.risk_tolerance,
            pricing_aggression=rng.random(),
            reinvestment_preference=rng.random(),
            innovation=rng.random(),
            executive_id=person.id,
            ceo_experience=max(1, person.leadership_experience),
            founder_id=person.id,
            construction_pipeline=[],
        )
        public_share_fraction = config.founder_public_share_fraction
        founder_shares = shares_outstanding * (1.0 - public_share_fraction)
        company.treasury_shares = shares_outstanding - founder_shares
        person.shares[company.id] = founder_shares
        company.active = True
        created.append(company)
        existing_counts[sector] = existing_counts.get(sector, 0) + 1

    return created, bank_reserves, len(created)


def resolve_distressed_companies(
    companies: list[Company],
    people: list[Person],
    bank_reserves: float,
    config: SimulationConfig,
    rng: random.Random,
) -> tuple[float, int]:
    defaults = 0
    for company in companies:
        if not company.active:
            continue
        company.loss_streak = company.loss_streak + 1 if company.profit < 0.0 else 0
        assets = (
            company.cash
            + company.property_inventory * config.housing_price
            + company.construction_in_progress
            + company.inventory * config.starting_food_price
            + company.goods_inventory * config.starting_goods_price
            + company.productive_capital_value
            + company.technology_asset_value
        )
        insolvent = company.debt > assets
        startup_failure = (
            company.founder_id is not None
            and company.age_months <= max(24, config.bankruptcy_months)
            and company.loss_streak >= config.bankruptcy_months
            and rng.random()
            < config.startup_failure_probability / config.bankruptcy_months
        )
        if not insolvent and not startup_failure:
            continue

        recovered = min(company.cash, company.debt)
        bank_reserves += recovered
        company.default_loss += max(0.0, company.debt - recovered)
        residual_equity = max(0.0, company.cash - recovered)
        holders = [
            holder for holder in [*people, *companies]
            if holder.id != company.id and holder.shares.get(company.id, 0.0) > 0.0
        ]
        shares_held = sum(holder.shares[company.id] for holder in holders)
        if residual_equity > 0.0 and shares_held > 0.0:
            for holder in holders:
                holder.cash += residual_equity * holder.shares[company.id] / shares_held
        if shares_held > 0.0:
            for asset_company_id, asset_shares in company.shares.items():
                if asset_company_id == company.id:
                    continue
                for holder in holders:
                    transferred_shares = (
                        asset_shares * holder.shares[company.id] / shares_held
                    )
                    if holder.id == asset_company_id and isinstance(holder, Company):
                        holder.treasury_shares += transferred_shares
                    else:
                        holder.shares[asset_company_id] = (
                            holder.shares.get(asset_company_id, 0.0)
                            + transferred_shares
                        )
        else:
            for asset_company_id, asset_shares in company.shares.items():
                issuer = next(
                    (
                        candidate
                        for candidate in companies
                        if candidate.id == asset_company_id and candidate.active
                    ),
                    None,
                )
                if issuer is not None:
                    issuer.treasury_shares += asset_shares
        company.active = False
        company.cash = 0.0
        company.debt = 0.0
        company.inventory = 0.0
        company.goods_inventory = 0.0
        company.property_inventory = 0
        company.production_capacity = 0.0
        company.productive_capital_value = 0.0
        company.technology_asset_value = 0.0
        company.tech_level = 0.0
        company.construction_in_progress = 0.0
        company.construction_pipeline.clear()
        company.stock_price = 0.0
        company.shares_outstanding = 0.0
        company.treasury_shares = 0.0
        for person in people:
            if person.employer_id == company.id:
                person.employer_id = None
                person.employer_tenure = 0
            person.shares.pop(company.id, None)
        for other in companies:
            if other.id != company.id:
                other.shares.pop(company.id, None)
        company.shares.clear()
        defaults += 1
    return bank_reserves, defaults
