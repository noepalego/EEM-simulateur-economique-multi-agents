from __future__ import annotations

from economy.models import Company, Person


def collect_income_taxes_and_pay_benefits(
    people: list[Person],
    government_balance: float,
    tax_rate: float,
    unemployment_benefit: float,
    unemployment_rate: float = 0.0,
    price_index: float = 100.0,
    cycle_sensitivity: float = 0.0,
    progressive_threshold: float = 0.0,
    top_marginal_rate: float = 0.0,
) -> tuple[float, float, float]:
    taxes_collected = 0.0
    benefits_paid = 0.0
    for person in people:
        taxable_income = max(0.0, person.income_this_turn)
        threshold = max(0.0, progressive_threshold)
        person.taxes_paid = (
            min(taxable_income, threshold) * tax_rate
            + max(0.0, taxable_income - threshold)
            * max(tax_rate, top_marginal_rate)
        )
        person.cash -= person.taxes_paid
        person.expenses_this_turn += person.taxes_paid
        person.cumulative_expenses += person.taxes_paid
        taxes_collected += person.taxes_paid
    available_funds = government_balance + taxes_collected
    benefit_per_person = (
        unemployment_benefit
        * max(0.0, price_index)
        / 100.0
        * (1.0 + max(0.0, cycle_sensitivity) * max(0.0, min(1.0, unemployment_rate)))
    )
    unemployed = [person for person in people if person.employer_id is None]
    total_entitlement = benefit_per_person * len(unemployed)
    benefit_per_recipient = (
        min(max(0.0, available_funds), total_entitlement) / len(unemployed)
        if unemployed
        else 0.0
    )
    for person in unemployed:
        person.cash += benefit_per_recipient
        person.income_this_turn += benefit_per_recipient
        person.lifetime_earnings += benefit_per_recipient
        benefits_paid += benefit_per_recipient
    return taxes_collected, benefits_paid, government_balance + taxes_collected - benefits_paid


def tax_company_profits(companies: list[Company], tax_rate: float) -> float:
    collected = 0.0
    for company in companies:
        if not company.active:
            continue
        taxable_profit = max(0.0, company.revenue - company.expenses)
        tax = min(max(0.0, company.cash), taxable_profit * tax_rate)
        company.cash -= tax
        company.expenses += tax
        collected += tax
    return collected
