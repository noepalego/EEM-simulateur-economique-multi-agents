from __future__ import annotations

from collections.abc import Mapping

from economy.models import Company, Person, Resources, SimulationConfig


def allocate_and_pay_labor(
    companies: list[Company],
    people: list[Person],
    starting_wage: float,
    config: SimulationConfig | None = None,
) -> tuple[float, float]:
    """Assign workers to the highest wage bids, subject to firms' cash."""
    config = config or SimulationConfig(starting_wage=starting_wage)
    previous_employers = {person.id: person.employer_id for person in people}
    companies_by_id = {company.id: company for company in companies}
    previous_employee_ids = {
        company.id: set(company.employees) for company in companies
    }
    previous_counts = {
        company.id: len(company.employees) for company in companies
    }
    desired_employees: dict[str, int] = {}
    for company in companies:
        desired = company.target_employees
        if not desired:
            desired = {
                "technology": 3,
                "food": 10,
                "goods": 7,
            }.get(company.sector, 5)
        previous_employee_count = len(company.employees)
        if previous_employee_count > 0 and company.wage_bill > 0.0:
            payroll_coverage = company.previous_revenue / company.wage_bill
            if payroll_coverage < config.payroll_coverage_target:
                # Ajustement progressif : maximum 2 licenciements par mois au lieu d'une chute brutale
                target_drop = int(previous_employee_count * max(0.0, payroll_coverage))
                desired = max(previous_employee_count - 2, target_drop)
            elif company.previous_profit < 0.0:
                desired = max(1, previous_employee_count - 1)
            elif company.previous_profit > 0.0:
                desired = min(desired, previous_employee_count + 1)
            else:
                desired = min(desired, previous_employee_count)
        elif previous_employee_count == 0 and company.age_months > 1:
            restart_reserve = max(starting_wage * 3.0, company.wage_offer * 2.0)
            desired = min(desired, 1) if company.cash >= restart_reserve else 0
        desired_employees[company.id] = desired
        company.employees.clear()
        company.wage_bill = 0.0
        if not company.active:
            continue
    for person in people:
        person.income_this_turn = 0.0
        person.dividend_income_this_turn = 0.0
        person.expenses_this_turn = 0.0

    job_offers: list[tuple[float, str, Company]] = []
    for company in companies:
        if not company.active:
            continue
        desired = desired_employees[company.id]
        affordable = int(max(0.0, company.cash - starting_wage * 0.25) // max(company.wage_offer, 1.0))
        vacant_positions = max(
            0, min(desired, affordable) - min(previous_counts[company.id], desired)
        )
        for _ in range(vacant_positions):
            job_offers.append((company.wage_offer, company.id, company))

    job_offers.sort(key=lambda offer: (-offer[0], offer[1]))
    available_people = sorted(people, key=lambda person: (-person.skill, person.id))
    offers_by_employer: dict[str, list[float]] = {}
    for wage, company_id, _ in job_offers:
        offers_by_employer.setdefault(company_id, []).append(wage)

    eligible_incumbents: set[str] = set()
    people_by_id = {person.id: person for person in people}
    for company in companies:
        if not company.active:
            continue
        affordable_positions = min(
            desired_employees[company.id],
            int(
                max(0.0, company.cash - starting_wage * 0.25)
                // max(company.wage_offer, 1.0)
            ),
        )
        incumbents = sorted(
            (
                people_by_id[person_id]
                for person_id in previous_employee_ids[company.id]
                if person_id in people_by_id
            ),
            key=lambda person: (-person.skill, person.id),
        )
        eligible_incumbents.update(
            person.id for person in incumbents[:affordable_positions]
        )

    employed_ids: set[str] = set()
    for person in people:
        employer_id = previous_employers[person.id]
        employer = companies_by_id.get(employer_id or "")
        if (
            employer is None
            or not employer.active
            or person.id not in eligible_incumbents
        ):
            continue
        competing_wages = [
            wage
            for other_id, wages in offers_by_employer.items()
            if other_id != employer.id
            for wage in wages
        ]
        reservation_wage = person.current_wage or employer.wage_offer
        if max(competing_wages, default=0.0) >= (
            reservation_wage * (1.0 + config.labor_mobility_premium)
        ):
            continue
        if len(employer.employees) >= min(
            desired_employees[employer.id],
            int(
                max(0.0, employer.cash - starting_wage * 0.25)
                // max(employer.wage_offer, 1.0)
            ),
        ):
            continue
        role = _employment_role(employer, person)
        wage = min(
            employer.wage_offer * _role_wage_multiplier(role, config),
            max(starting_wage * 0.55, employer.cash),
        )
        employer.cash -= wage
        employer.wage_bill += wage
        employer.expenses += wage
        person.cash += wage
        person.income_this_turn = wage
        person.lifetime_earnings += wage
        person.current_wage = wage
        person.employment_role = role
        person.employer_tenure += 1
        person.skill = min(2.0, person.skill + 0.0015)
        employer.employees.append(person.id)
        employed_ids.add(person.id)

    for _, _, company in job_offers:
        if not company.active:
            continue
        affordable_positions = min(
            desired_employees[company.id],
            int(
                max(0.0, company.cash - starting_wage * 0.25)
                // max(company.wage_offer, 1.0)
            ),
        )
        if len(company.employees) >= affordable_positions:
            continue
        eligible_people = [
            person
            for person in available_people
            if person.id not in employed_ids
            and (
                previous_employers[person.id] is None
                or person.id not in eligible_incumbents
                or company.wage_offer
                >= (person.current_wage or starting_wage)
                * (1.0 + config.labor_mobility_premium)
            )
        ]
        if not eligible_people:
            continue
        person = eligible_people[0]
        role = _employment_role(company, person)
        wage = min(
            company.wage_offer * _role_wage_multiplier(role, config),
            max(starting_wage * 0.55, company.cash),
        )
        company.cash -= wage
        company.wage_bill += wage
        company.expenses += wage
        company.employees.append(person.id)
        person.employer_id = company.id
        person.employer_tenure = (
            person.employer_tenure + 1
            if previous_employers[person.id] == company.id
            else 1
        )
        person.cash += wage
        person.income_this_turn = wage
        person.lifetime_earnings += wage
        person.skill = min(2.0, person.skill + 0.0015)
        person.current_wage = wage
        person.employment_role = role
        employed_ids.add(person.id)

    for person in people:
        if person.id not in employed_ids:
            person.employer_id = None
            person.employer_tenure = 0
            person.skill = max(0.5, person.skill - 0.0005)
            person.current_wage = 0.0
            person.employment_role = "Sans emploi"

    wages = sum(company.wage_bill for company in companies if company.active)
    hired = len(employed_ids)
    average_wage = wages / hired if hired else starting_wage
    return average_wage, (len(people) - hired) / len(people) if people else 0.0


def _employment_role(company: Company, person: Person) -> str:
    if person.id == company.executive_id:
        return "Direction"
    if person.skill >= 1.35:
        return "Management"
    if person.skill >= 1.1:
        return "Spécialiste"
    return "Production"


def _role_wage_multiplier(role: str, config: SimulationConfig) -> float:
    return {
        "Direction": config.executive_wage_multiplier,
        "Management": config.manager_wage_multiplier,
        "Spécialiste": config.specialist_wage_multiplier,
    }.get(role, 1.0)


def hire_service_workers(
    people: list[Person],
    resources: Resources,
    monthly_wage: float,
    payout_rate: float,
) -> tuple[int, float]:
    # Suppression du fonds artificiel : on ne crée plus d'emplois « services » payés par resources.market_cash
    resources.supplier_income = 0.0
    resources.supplier_employment = 0
    return 0, 0.0


def effective_worker_count(
    company: Company,
    worker_skills: Mapping[str, float | tuple[float, float]],
) -> float:
    effective_workers = 0.0
    for employee_id in company.employees:
        worker_data = worker_skills.get(employee_id)
        if worker_data is None:
            continue
        if isinstance(worker_data, tuple):
            skill, technology_level = worker_data
        else:
            skill, technology_level = worker_data, 0.0
        effective_workers += max(0.25, min(2.0, skill)) * (
            1.0 + min(0.45, max(0.0, technology_level) * 0.15)
        )
    return effective_workers


def workforce_targets(config: SimulationConfig) -> dict[str, int]:
    # cibler 80% de taux d'emploi total des ménages (= emplois firms + services)
    population = config.population_size
    firm_target = int(round(population * config.target_employment_rate * 0.55))
    total_companies = (len({
        "food":1,"goods":1,"technology":1,"real_estate":1,"materials":1,"bank":1
    }) * config.companies_per_sector)
    avg_per_company = max(1, firm_target // total_companies)
    baseline = {
        "food": avg_per_company + 3,
        "goods": avg_per_company + 2,
        "technology": avg_per_company,
        "real_estate": avg_per_company,
        "materials": avg_per_company,
        "bank": max(1, avg_per_company // 2),
    }
    base_jobs = sum(baseline.values()) * config.companies_per_sector
    target_jobs = round(config.population_size * config.target_employment_rate)
    additional_groups = max(
        0, target_jobs - base_jobs
    ) // config.companies_per_sector
    group_weights = {
        "food": 4,
        "goods": 3,
        "technology": 1,
        "real_estate": 1,
    }
    group_allocations = {sector: 0 for sector in group_weights}
    total_weight = sum(group_weights.values())
    for _ in range(additional_groups):
        sector = max(
            group_weights,
            key=lambda key: (
                additional_groups * group_weights[key] / total_weight
                - group_allocations[key],
                -list(group_weights).index(key),
            ),
        )
        group_allocations[sector] += 1
    targets: dict[str, int] = {}
    for sector, base_per_company in baseline.items():
        extra = group_allocations.get(sector, 0)
        targets[sector] = base_per_company + extra
    return targets
