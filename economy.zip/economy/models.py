from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class SimulationConfig:
    population_size: int = 240
    companies_per_sector: int = 3
    initial_company_cash: float = 400000.0
    initial_person_cash: float = 8000.0
    raw_materials: float = 300000.0
    land_units: int = 250
    starting_food_price: float = 120.0
    starting_goods_price: float = 100.0
    starting_rent: float = 700.0
    starting_wage: float = 1400.0
    income_tax_rate: float = 0.08
    corporate_tax_rate: float = 0.12
    unemployment_benefit: float = 300.0
    food_input_cost: float = 20.0
    goods_input_cost: float = 25.0
    raw_material_unit_price: float = 12.0
    raw_material_extraction_cost: float = 0.5
    raw_material_extraction_productivity: float = 250.0
    material_recovery_rate: float = 0.90
    food_income_budget_share: float = 0.32
    food_cash_draw_rate: float = 0.12
    goods_income_budget_share: float = 0.22
    goods_cash_draw_rate: float = 0.10
    food_productivity: float = 24.0
    goods_productivity: float = 24.0
    payroll_coverage_target: float = 0.80
    loss_wage_adjustment_strength: float = 0.70
    target_employment_rate: float = 0.60
    tech_unit_price: float = 900.0
    technology_depreciation_rate: float = 0.02
    housing_build_cost: float = 70000.0
    housing_price: float = 120000.0
    build_time_months: int = 6
    loan_interest_rate: float = 0.004
    credit_risk_spread: float = 0.0025
    maximum_loan_leverage: float = 3.0
    maximum_debt_service_ratio: float = 0.05
    acquisition_probability: float = 0.04
    merger_size_ratio: float = 2.0
    startup_threshold: float = 100000.0
    startup_investment_fraction: float = 0.65
    startup_failure_probability: float = 0.30
    dividend_payout_rate: float = 0.12
    competitive_pricing_strength: float = 0.06
    investment_retention_rate: float = 0.08
    company_founder_probability: float = 0.12
    wage_productivity_share: float = 0.35
    trait_variance: float = 0.16
    random_promotion_strength: float = 0.25
    ceo_term_months: int = 12
    bank_initial_reserves: float = 5000000.0
    household_stock_investment_rate: float = 0.15
    executive_bonus_rate: float = 0.03
    household_saving_rate_base: float = 0.08
    household_saving_rate_income_elasticity: float = 0.12
    bankruptcy_months: int = 6
    inventory_spoilage_rate: float = 0.04
    target_inventory_months: float = 1.5
    market_price_ceiling: float = 350.0
    stock_book_value_weight: float = 0.55
    stock_earnings_multiple: float = 7.0
    stock_adjustment_speed: float = 0.18
    cpi_food_weight: float = 0.45
    cpi_goods_weight: float = 0.30
    cpi_rent_weight: float = 0.25
    wage_indexation_rate: float = 0.35
    unemployment_benefit_cycle_sensitivity: float = 0.50
    labor_mobility_premium: float = 0.08
    household_rent_income_share: float = 0.35
    rent_affordability_weight: float = 0.25
    housing_maintenance_rate: float = 0.002
    inventory_holding_cost_rate: float = 0.002
    household_propensity_variance: float = 0.25
    consumer_price_elasticity: float = 1.5
    inventory_discount_strength: float = 0.08
    wage_unemployment_sensitivity: float = 0.08
    supplier_wage_payout_rate: float = 0.30
    income_tax_threshold: float = 3000.0
    top_marginal_income_tax_rate: float = 0.05
    inflation_target: float = 0.002
    policy_rate_inflation_sensitivity: float = 0.04
    policy_rate_unemployment_sensitivity: float = 0.004
    mortgage_down_payment_rate: float = 0.20
    mortgage_payment_income_share: float = 0.30
    mortgage_interest_rate: float = 0.004
    mortgage_term_months: int = 360
    monthly_population_growth_rate: float = 0.001
    maximum_population_growth: float = 0.50
    quality_trait_variance: float = 0.20
    quality_preference_strength: float = 1.0
    capacity_expansion_reinvestment_rate: float = 0.30
    productive_capacity_unit_cost: float = 2500.0
    productive_capacity_depreciation_rate: float = 0.005
    technology_productivity: float = 3.0
    technology_knowledge_use_rate: float = 0.01
    technology_price_growth: float = 0.25
    technology_business_budget_share: float = 0.01
    technology_business_profit_share: float = 0.20
    technology_business_max_level: float = 5.0
    technology_household_budget_share: float = 0.05
    technology_household_savings_share: float = 0.001
    technology_household_price_fraction: float = 0.05
    technology_household_supply_share: float = 0.30
    technology_household_level_gain: float = 0.05
    technology_household_max_level: float = 3.0
    technology_household_depreciation_rate: float = 0.01
    founder_public_share_fraction: float = 0.25
    executive_wage_multiplier: float = 1.10
    manager_wage_multiplier: float = 1.05
    specialist_wage_multiplier: float = 1.02
    ceo_term_indeterminate: bool = True
    ceo_equity_bonus_rate: float = 0.02
    acquisition_probability_boost: float = 0.03
    profit_margin_target: float = 0.05
    seed: int = 7

    def __post_init__(self) -> None:
        self.population_size = max(1, self.population_size)
        self.companies_per_sector = max(1, self.companies_per_sector)
        self.land_units = max(0, self.land_units)
        self.build_time_months = max(1, self.build_time_months)
        self.ceo_term_months = max(1, self.ceo_term_months)
        self.bankruptcy_months = max(1, self.bankruptcy_months)
        self.mortgage_term_months = max(1, self.mortgage_term_months)
        self.technology_productivity = max(0.01, self.technology_productivity)
        self.productive_capacity_unit_cost = max(
            1.0, self.productive_capacity_unit_cost
        )
        self.technology_household_max_level = max(
            0.0, self.technology_household_max_level
        )
        self.technology_business_max_level = max(
            0.0, min(10.0, self.technology_business_max_level)
        )
        self.target_inventory_months = max(
            0.0, min(3.0, self.target_inventory_months)
        )
        self.merger_size_ratio = max(1.0, self.merger_size_ratio)
        self.maximum_loan_leverage = max(0.0, self.maximum_loan_leverage)
        self.maximum_debt_service_ratio = max(
            0.0, min(1.0, self.maximum_debt_service_ratio)
        )
        self.loan_interest_rate = max(0.0, min(1.0, self.loan_interest_rate))
        self.credit_risk_spread = max(0.0, min(0.25, self.credit_risk_spread))
        self.trait_variance = max(0.0, min(1.0, self.trait_variance))
        for field_name in (
            "initial_company_cash",
            "initial_person_cash",
            "raw_materials",
            "unemployment_benefit",
            "food_input_cost",
            "goods_input_cost",
            "raw_material_unit_price",
            "raw_material_extraction_cost",
            "startup_threshold",
            "bank_initial_reserves",
            "income_tax_threshold",
        ):
            setattr(self, field_name, max(0.0, getattr(self, field_name)))
        for field_name in (
            "executive_wage_multiplier",
            "manager_wage_multiplier",
            "specialist_wage_multiplier",
        ):
            setattr(
                self,
                field_name,
                max(0.5, min(3.0, getattr(self, field_name))),
            )
        for field_name in (
            "starting_food_price",
            "starting_goods_price",
            "starting_rent",
            "starting_wage",
            "food_productivity",
            "goods_productivity",
            "raw_material_extraction_productivity",
            "tech_unit_price",
            "housing_build_cost",
            "housing_price",
            "market_price_ceiling",
        ):
            setattr(self, field_name, max(0.01, getattr(self, field_name)))
        self.market_price_ceiling = max(
            self.market_price_ceiling,
            self.starting_food_price,
            self.starting_goods_price,
        )
        for field_name in (
            "income_tax_rate",
            "corporate_tax_rate",
            "startup_failure_probability",
            "dividend_payout_rate",
            "acquisition_probability",
            "company_founder_probability",
            "competitive_pricing_strength",
            "payroll_coverage_target",
            "loss_wage_adjustment_strength",
            "investment_retention_rate",
            "wage_productivity_share",
            "random_promotion_strength",
            "household_stock_investment_rate",
            "executive_bonus_rate",
            "inventory_spoilage_rate",
            "startup_investment_fraction",
            "target_employment_rate",
            "technology_depreciation_rate",
            "stock_book_value_weight",
            "stock_adjustment_speed",
            "material_recovery_rate",
            "food_income_budget_share",
            "food_cash_draw_rate",
            "goods_income_budget_share",
            "goods_cash_draw_rate",
            "cpi_food_weight",
            "cpi_goods_weight",
            "cpi_rent_weight",
            "wage_indexation_rate",
            "unemployment_benefit_cycle_sensitivity",
            "labor_mobility_premium",
            "household_rent_income_share",
            "rent_affordability_weight",
            "housing_maintenance_rate",
            "inventory_holding_cost_rate",
            "household_propensity_variance",
            "inventory_discount_strength",
            "wage_unemployment_sensitivity",
            "supplier_wage_payout_rate",
            "top_marginal_income_tax_rate",
            "inflation_target",
            "policy_rate_inflation_sensitivity",
            "policy_rate_unemployment_sensitivity",
            "mortgage_down_payment_rate",
            "mortgage_payment_income_share",
            "mortgage_interest_rate",
            "monthly_population_growth_rate",
            "maximum_population_growth",
            "quality_preference_strength",
            "capacity_expansion_reinvestment_rate",
            "productive_capacity_depreciation_rate",
            "technology_knowledge_use_rate",
            "technology_price_growth",
            "technology_business_budget_share",
            "technology_business_profit_share",
            "technology_household_budget_share",
            "technology_household_savings_share",
            "technology_household_price_fraction",
            "technology_household_supply_share",
            "technology_household_level_gain",
            "technology_household_depreciation_rate",
            "founder_public_share_fraction",
        ):
            value = getattr(self, field_name)
            setattr(self, field_name, max(0.0, min(1.0, value)))
        self.quality_trait_variance = max(
            0.0, min(0.5, self.quality_trait_variance)
        )
        self.stock_earnings_multiple = max(0.0, min(30.0, self.stock_earnings_multiple))
        self.consumer_price_elasticity = max(
            0.0, min(5.0, self.consumer_price_elasticity)
        )
        self.technology_household_level_gain = max(
            0.001, self.technology_household_level_gain
        )


@dataclass
class Person:
    id: str
    name: str
    cash: float
    employer_id: str | None = None
    shares: dict[str, float] = field(default_factory=dict)
    owns_home: bool = False
    investment_homes: int = 0
    rental_owner_id: str | None = None
    skill: float = 1.0
    income_this_turn: float = 0.0
    dividend_income_this_turn: float = 0.0
    expenses_this_turn: float = 0.0
    last_food_bought: float = 0.0
    last_goods_bought: float = 0.0
    taxes_paid: float = 0.0
    employer_tenure: int = 0
    lifetime_earnings: float = 0.0
    cumulative_expenses: float = 0.0
    leadership_experience: int = 0
    risk_tolerance: float = 0.5
    current_wage: float = 0.0
    consumption_propensity: float = 1.0
    quality_preference: float = 1.0
    technology_level: float = 0.0
    employment_role: str = "Sans emploi"
    mortgage_debt: float = 0.0
    mortgage_rate: float = 0.0
    mortgage_payment: float = 0.0
    mortgage_months_remaining: int = 0
    founded_company: bool = False
    wealth_history: list[float] = field(default_factory=list)
    financial_history: list[dict[str, float]] = field(default_factory=list)


@dataclass
class Company:
    id: str
    name: str
    sector: str
    cash: float
    wage_offer: float
    price: float = 1.0
    inventory: float = 0.0
    goods_inventory: float = 0.0
    tech_level: float = 0.0
    technology_asset_value: float = 0.0
    quality_trait: float = 1.0
    production_capacity: float = 0.0
    productive_capital_value: float = 0.0
    employees: list[str] = field(default_factory=list)
    shares: dict[str, float] = field(default_factory=dict)
    shares_outstanding: float = 1000.0
    treasury_shares: float = 1000.0
    property_inventory: int = 0
    tech_inventory: float = 0.0
    revenue: float = 0.0
    expenses: float = 0.0
    profit: float = 0.0
    previous_profit: float = 0.0
    previous_revenue: float = 0.0
    stock_price: float = 20.0
    previous_stock_price: float = 20.0
    wage_bill: float = 0.0
    capital_expenditure: float = 0.0
    property_cost_sold_this_turn: float = 0.0
    depreciation_this_turn: float = 0.0
    interest_paid_this_turn: float = 0.0
    principal_paid_this_turn: float = 0.0
    default_loss: float = 0.0
    materials_supplied_this_turn: float = 0.0
    units_sold: float = 0.0
    units_produced: float = 0.0
    target_employees: int = 0
    stock_trade_volume: float = 0.0
    dividend_paid: float = 0.0
    debt: float = 0.0
    debt_interest_rate: float | None = None
    age_months: int = 0
    loss_streak: int = 0
    construction_in_progress: float = 0.0
    acquisition_count: int = 0
    productivity_trait: float = 1.0
    risk_tolerance: float = 0.5
    pricing_aggression: float = 0.5
    reinvestment_preference: float = 0.5
    innovation: float = 0.5
    executive_id: str | None = None
    ceo_experience: int = 0
    ceo_tenure: int = 0
    last_acquisition_month: int = -1000
    construction_pipeline: list[int] = field(default_factory=list)
    financial_history: list[dict[str, float]] = field(default_factory=list)
    customer_revenue: dict[str, float] = field(default_factory=dict)
    supplier_spending: dict[str, float] = field(default_factory=dict)
    active: bool = True
    founder_id: str | None = None
    bank_loan_accounts: dict[str, float] = field(default_factory=dict)
    bank_equity: float = 0.0


@dataclass
class Resources:
    raw_materials: float
    land_units: int
    knowledge: float
    market_cash: float = 0.0
    raw_material_price: float = 12.0
    supplier_income: float = 0.0
    supplier_employment: int = 0
    household_technology_revenue: float = 0.0
    household_technology_units: float = 0.0
    recycled_materials: float = 0.0
    recycling_pending: float = 0.0


@dataclass
class MarketRecord:
    month: int
    food_price: float
    average_wage: float
    food_sold: float
    unemployment: float
    housing_rent: float
    total_revenue: float
    total_profit: float
    event: str
    goods_price: float = 6.0
    goods_sold: float = 0.0
    unmet_food_demand: float = 0.0
    unmet_goods_demand: float = 0.0
    tax_revenue: float = 0.0
    benefits_paid: float = 0.0
    dividends_paid: float = 0.0
    secondary_volume: float = 0.0
    homes_occupied: int = 0
    vacancies: int = 0
    company_prices: dict[str, float] = field(default_factory=dict)
    top_household_wealth: float = 0.0
    top_company_wealth: float = 0.0
    household_gini: float = 0.0
    household_wealth_median: float = 0.0
    household_wealth_total: float = 0.0
    household_top10_share: float = 0.0
    company_debt: float = 0.0
    active_companies: int = 0
    acquisitions: int = 0
    startups: int = 0
    bankruptcies: int = 0
    bank_reserves: float = 0.0
    employed_count: int = 0
    household_income: float = 0.0
    household_spending: float = 0.0
    raw_materials_remaining: float = 0.0
    recycled_materials_remaining: float = 0.0
    consumer_price_index: float = 100.0
    inflation_rate: float = 0.0
    real_average_wage: float = 0.0
    real_household_income: float = 0.0
    nominal_gdp: float = 0.0
    real_gdp: float = 0.0
    household_technology_revenue: float = 0.0
    household_technology_units: float = 0.0
    food_inventory: float = 0.0
    goods_inventory: float = 0.0
    technology_inventory: float = 0.0
    food_produced: float = 0.0
    goods_produced: float = 0.0
    production_capacity_investment: float = 0.0
    new_households: int = 0
    population_count: int = 0
    supplier_income: float = 0.0
    supplier_employment: int = 0
    household_tax_revenue: float = 0.0
    policy_rate: float = 0.0
    mortgage_debt: float = 0.0
    sector_market_share: dict[str, float] = field(default_factory=dict)
    sector_employment: dict[str, int] = field(default_factory=dict)
    sector_revenue: dict[str, float] = field(default_factory=dict)
    sector_profit: dict[str, float] = field(default_factory=dict)
    sector_average_wage: dict[str, float] = field(default_factory=dict)
    bank_loan_portfolio: float = 0.0
    bank_equity: float = 0.0
    bank_interest_income: float = 0.0
    housing_construction: float = 0.0
    resource_market_cash: float = 0.0
    raw_material_price: float = 12.0
